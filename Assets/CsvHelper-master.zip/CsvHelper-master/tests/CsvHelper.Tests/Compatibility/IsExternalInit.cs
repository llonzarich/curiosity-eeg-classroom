﻿#if NETFRAMEWORK
namespace System.Runtime.CompilerServices
{
	internal static class IsExternalInit { }
}
#endif
