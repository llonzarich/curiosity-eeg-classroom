﻿# Configuration

## Topics
&nbsp; | &nbsp;
- | -
[Class Maps](~/examples/configuration/class-maps) | Configure CSV structure with a class map.
[Attributes](~/examples/configuration/attributes) | Configure CSV structure with attributes.
