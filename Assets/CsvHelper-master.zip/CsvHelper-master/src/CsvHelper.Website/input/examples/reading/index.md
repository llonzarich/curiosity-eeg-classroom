﻿# Reading

Topics | &nbsp;
- | -
[Get Class Records](~/examples/reading/get-class-records) | 
[Get Dynamic Records](~/examples/reading/get-dynamic-records) | 
[Get Anonymous Type Records](~/examples/reading/get-anonymous-type-records) | 
[Enumerate Class Records](~/examples/reading/enumerate-class-records) | 
[Reading by Hand](~/examples/reading/reading-by-hand) | 
[Reading Multiple Data Sets](~/examples/reading/reading-multiple-data-sets) | 
[Reading Multiple Record Types](~/examples/reading/reading-multiple-record-types) | 
