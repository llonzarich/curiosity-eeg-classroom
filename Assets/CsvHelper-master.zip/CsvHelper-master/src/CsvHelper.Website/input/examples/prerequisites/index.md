﻿# Prerequisites

Here are some prerequisites that are needed for using CsvHelper. These are .NET basics that are implied knowledge when using CsvHelper. [Microsoft has excellent documentation](https://docs.microsoft.com/dotnet/){target=_blank} that can you can use to learn more.

Topics | &nbsp;
- | -
[Using and Dispose](~/examples/prerequisites/using-and-dispose) |
[Reading and Writing Files](~/examples/prerequisites/reading-and-writing-files) |
[Streams](~/examples/prerequisites/streams) |
