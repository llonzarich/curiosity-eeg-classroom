﻿## Preview the docs locally

```
> dotnet run -- preview --virtual-dir CsvHelper
```

Open browser to http://localhost:5080/CsvHelper
