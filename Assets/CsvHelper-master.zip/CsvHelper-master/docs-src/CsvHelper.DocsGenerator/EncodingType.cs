﻿namespace CsvHelper.DocsGenerator
{
	public enum EncodingType
	{
		// Generic&ltParameter&gt;
		Html = 0,

		// Generic<Parameter>
		Code = 1,

		// Generic{Parameter}
		Xml = 2
	}
}
